=== Polymate Diagnostic V2 ===
Contributors: olivierguex
Tags: diagnostic, score, business, advisory
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 0.2.0
License: GPLv2 or later

Diagnostic interactif Polymate pour WordPress avec sauvegarde et mode client/interne.

== Description ==

Fonctionnalités V2 :
- shortcode [polymate_diagnostic]
- parcours par étapes
- scoring maturité / urgence / complétude
- restitution client
- mode client / interne
- sauvegarde des diagnostics dans WordPress
- chargement / suppression des dossiers enregistrés
- réglages simples dans l’admin
- export JSON et impression navigateur
- champ pour future URL de service PDF externe

== Installation ==

1. Téléverse le zip dans Extensions > Ajouter.
2. Active le plugin.
3. Va dans Polymate Diagnostic > Réglages.
4. Place le shortcode [polymate_diagnostic] sur une page.

== Notes ==

Cette V2 met en place la structure WordPress solide :
- données enregistrées en post type privé
- endpoints REST internes
- modes client / interne

La génération PDF premium serveur pourra être branchée ensuite via l’URL de service PDF externe.
