
(function(){
  const cfg = window.PolymateDiagnosticV2Config || {};
  const dimensions = cfg.dimensions || [];
  const answers = {};
  let currentStep = 0;
  let reportMode = false;
  let currentSavedId = null;

  const options = [
    { value: 0, label: '0 · Critique' },
    { value: 1, label: '1 · Fragile' },
    { value: 2, label: '2 · Partiel' },
    { value: 3, label: '3 · Structuré' },
    { value: 'na', label: 'N/A', className: 'pm-na' }
  ];

  document.querySelectorAll('[data-polymate-app]').forEach(initApp);

  function initApp(app){
    const el = {
      navList: app.querySelector('[data-nav-list]'),
      savedList: app.querySelector('[data-saved-list]'),
      stepKicker: app.querySelector('[data-step-kicker]'),
      stepTitle: app.querySelector('[data-step-title]'),
      stepDesc: app.querySelector('[data-step-desc]'),
      progressLabel: app.querySelector('[data-progress-label]'),
      progressBar: app.querySelector('[data-progress-bar]'),
      questionStack: app.querySelector('[data-question-stack]'),
      stepHint: app.querySelector('[data-step-hint]'),
      liveMaturity: app.querySelector('[data-live-maturity]'),
      liveUrgency: app.querySelector('[data-live-urgency]'),
      liveCompletion: app.querySelector('[data-live-completion]'),
      liveMaturityBar: app.querySelector('[data-live-maturity-bar]'),
      liveUrgencyBar: app.querySelector('[data-live-urgency-bar]'),
      liveCompletionBar: app.querySelector('[data-live-completion-bar]'),
      wizardView: app.querySelector('[data-view="wizard"]'),
      reportView: app.querySelector('[data-view="report"]'),
      reportReco: app.querySelector('[data-report-reco]'),
      reportSummary: app.querySelector('[data-report-summary]'),
      reportTags: app.querySelector('[data-report-tags]'),
      prioritiesList: app.querySelector('[data-priorities-list]'),
      commercialList: app.querySelector('[data-commercial-list]'),
      strengthsList: app.querySelector('[data-strengths-list]'),
      weaknessesList: app.querySelector('[data-weaknesses-list]'),
      internalOnly: app.querySelectorAll('[data-internal-only]'),
      internalNotes: app.querySelector('[data-internal-notes]'),
      metaClient: app.querySelector('[data-meta-client]'),
      metaDate: app.querySelector('[data-meta-date]'),
      metaReference: app.querySelector('[data-meta-reference]'),
      metaOwner: app.querySelector('[data-meta-owner]'),
      metaTheme: app.querySelector('[data-meta-theme]'),
      reportModeSelect: app.querySelector('[data-report-mode]'),
      saveStatus: app.querySelector('[data-save-status]'),
      actions: app.querySelectorAll('[data-action]'),
    };

    if (el.metaDate) el.metaDate.value = new Date().toISOString().slice(0, 10);
    if (el.metaTheme && cfg.themeDefault) el.metaTheme.value = cfg.themeDefault;
    if (el.metaOwner && cfg.defaultOwner && !el.metaOwner.value) el.metaOwner.value = cfg.defaultOwner;

    el.actions.forEach(btn => {
      btn.addEventListener('click', async function(){
        const action = this.getAttribute('data-action');
        if (action === 'demo') fillDemo();
        if (action === 'reset') resetAll();
        if (action === 'report') { reportMode = true; refresh(); }
        if (action === 'back') { reportMode = false; refresh(); }
        if (action === 'next') goNext();
        if (action === 'prev') goPrev();
        if (action === 'print') window.print();
        if (action === 'download-json') downloadJson(el);
        if (action === 'save') await saveDiagnostic(el);
      });
    });

    if (el.reportModeSelect) {
      el.reportModeSelect.addEventListener('change', refresh);
    }

    function countCompletion(){
      const total = dimensions.reduce((sum, d) => sum + d.questions.length, 0);
      const answered = dimensions.reduce((sum, d) => sum + d.questions.filter(q => answers[q.id] !== undefined).length, 0);
      return { total, answered, percent: total ? Math.round((answered / total) * 100) : 0 };
    }

    function scoreDimension(dim){
      const vals = dim.questions.map(q => answers[q.id]).filter(v => v !== undefined && v !== 'na' && Number.isFinite(v));
      if (!vals.length) return null;
      return Math.round((vals.reduce((a,b)=>a+b,0) / (vals.length * 3)) * 100);
    }

    function getDimensionScores(){
      return dimensions.map(dim => ({ title: dim.title, score: scoreDimension(dim), weight: dim.weight }));
    }

    function calcMaturity(scores){
      const valid = scores.filter(d => d.score !== null);
      if (!valid.length) return 0;
      return Math.round(valid.reduce((sum, d) => sum + d.score * d.weight, 0) / valid.reduce((sum, d) => sum + d.weight, 0));
    }

    function calcUrgency(){
      let sum = 0, max = 0;
      dimensions.forEach(dim => dim.questions.forEach(q => {
        const v = answers[q.id];
        if (Array.isArray(q.urgency) && v !== undefined && v !== 'na' && Number.isFinite(v)) {
          sum += q.urgency[v];
          max += Math.max.apply(null, q.urgency);
        }
      }));
      return max ? Math.round((sum / max) * 100) : 0;
    }

    function calcStability(scores){
      const vals = scores.filter(d => d.score !== null).map(d => d.score);
      if (vals.length < 2) return null;
      const avg = vals.reduce((a,b)=>a+b,0) / vals.length;
      const variance = vals.reduce((a,b)=>a + Math.pow(b - avg, 2), 0) / vals.length;
      const stdev = Math.sqrt(variance);
      return Math.max(0, Math.min(100, Math.round(100 - stdev * 1.6)));
    }

    function recommendation(maturity, urgency, completion){
      if (completion < 35) return { name: 'Lecture partielle', text: 'Le diagnostic n’est pas encore assez complété pour recommander proprement une formule ferme.', tags: ['Compléter le diagnostic','Lecture provisoire'] };
      if (urgency >= 68 || (maturity <= 42 && urgency >= 45)) return { name: 'Executive', text: 'La priorité est une reprise en main rapide. On sécurise, on clarifie et on remet de l’ordre avant toute logique d’entretien.', tags: ['Urgence élevée','Remise à niveau','Décisions rapides'] };
      if (maturity < 58 || (urgency >= 38 && maturity < 70)) return { name: 'Structure', text: 'L’entreprise paraît viable, mais sa base reste trop fragile ou trop artisanale. Il faut d’abord structurer ce qui tient l’activité au quotidien.', tags: ['Base à consolider','Organisation','Processus'] };
      if (maturity < 82 || urgency >= 18) return { name: 'Core', text: 'Le socle existe déjà. Le besoin dominant est un pilotage global régulier pour arbitrer, suivre et éviter le retour du désordre.', tags: ['Pilotage continu','Vision transversale','Entretien intelligent'] };
      return { name: 'Start', text: 'Le niveau de maturité est déjà solide. Un accompagnement ciblé ou flexible peut suffire.', tags: ['Besoin ciblé','Entrée souple','Mission ponctuelle'] };
    }

    function summary(maturity, urgency, completion, scores, stability){
      const valid = scores.filter(d => d.score !== null);
      if (!valid.length) return 'Le diagnostic est vide pour le moment.';
      const weak = valid.slice().sort((a,b)=>a.score-b.score).slice(0,3).map(d=>d.title);
      const strong = valid.slice().sort((a,b)=>b.score-a.score).slice(0,2).map(d=>d.title);
      let tone = urgency >= 65 ? 'La lecture fait apparaître une tension élevée : il faut sécuriser avant d’optimiser.' :
        maturity < 55 ? 'Le potentiel existe, mais plusieurs fondations restent trop fragiles pour un pilotage confortable.' :
        maturity < 80 ? 'L’entreprise semble tenir debout, avec un vrai enjeu de consolidation et de pilotage transversal.' :
        'La structure paraît déjà plutôt mûre.';
      let stabilityText = stability === null ? 'La stabilité inter-dimensions n’est pas encore lisible.' :
        stability >= 75 ? 'Le profil paraît relativement homogène.' :
        stability >= 55 ? 'Le profil présente quelques déséquilibres notables.' :
        'Le profil est contrasté.';
      return `<strong>Lecture synthétique.</strong> ${tone} Zones sensibles : <strong>${weak.join(', ')}</strong>. Points d’appui : <strong>${strong.join(', ')}</strong>. <strong>Maturité :</strong> ${maturity}/100 · <strong>Urgence :</strong> ${urgency}/100 · <strong>Complétude :</strong> ${completion}%. ${stabilityText}`;
    }

    function priorities(scores){
      const map = {
        'Vision & gouvernance':'Clarifier le cap, les responsabilités et le degré de dépendance au dirigeant.',
        'Finance & pilotage':'Remettre en place une lecture régulière de la trésorerie, du budget et des chiffres utiles à la décision.',
        'Opérations & organisation':'Stabiliser les processus clés pour réduire les pertes de temps et la dépendance à quelques personnes.',
        'Administratif & RH':'Sécuriser la base administrative et éviter que le dirigeant absorbe tout l’arrière-office.',
        'Digital & systèmes':'Rationaliser les outils, sécuriser les données et transformer le digital en levier plutôt qu’en friction.',
        'Marketing & communication':'Clarifier le positionnement et structurer un minimum le suivi commercial.',
        'Données & pilotage global':'Créer un cockpit simple avec quelques indicateurs fiables pour lire l’entreprise en continu.',
        'Risques & signaux faibles':'Traiter les dépendances, tensions cachées et projets sensibles avant qu’ils ne deviennent critiques.'
      };
      return scores.filter(d => d.score !== null).sort((a,b)=>a.score-b.score).slice(0,3).map((d,i)=>({title:`Priorité ${i+1} — ${d.title}`, text:map[d.title]}));
    }

    function commercial(reco){
      const map = {
        'Lecture partielle':[{'title':'Étape suivante','text':'Compléter le diagnostic avant de figer une formule.'}],
        'Executive':[{'title':'Logique d’intervention','text':'Mission courte et intense de reprise en main.'}],
        'Structure':[{'title':'Logique d’intervention','text':'Consolider ce qui tient l’activité : processus, organisation, base administrative.'}],
        'Core':[{'title':'Logique d’intervention','text':'Mettre en place un pilotage global récurrent, transversal et lisible.'}],
        'Start':[{'title':'Logique d’intervention','text':'Traiter un besoin ciblé sans déployer d’emblée une structure lourde.'}]
      };
      return map[reco.name] || map['Lecture partielle'];
    }

    function internalNotes(state){
      return [
        { title: 'Lecture stratégique', text: `Maturité ${state.maturity}/100, urgence ${state.urgency}/100, stabilité ${state.stability === null ? '—' : state.stability + '/100'}.` },
        { title: 'Hypothèse Polymate', text: state.reco.name === 'Executive' ? 'Mandat de reprise en main à cadrer rapidement.' : state.reco.name === 'Structure' ? 'Mission de structuration avec possibilité de bascule vers Core.' : state.reco.name === 'Core' ? 'Mandat d’entretien stratégique régulier plausible.' : 'Point d’entrée ciblé possible avant élargissement.' },
        { title: 'Point de vigilance', text: state.weaknesses.length ? `Les dimensions les plus basses sont : ${state.weaknesses.join(', ')}.` : 'Pas encore assez d’éléments pour isoler les points faibles.' }
      ];
    }

    function renderStep(){
      const dim = dimensions[currentStep];
      el.stepKicker.textContent = `Étape ${currentStep + 1} sur ${dimensions.length}`;
      el.stepTitle.textContent = dim.title;
      el.stepDesc.textContent = dim.desc;
      el.questionStack.innerHTML = dim.questions.map((q, i) => `
        <div class="pm-question">
          <div class="pm-question-title">${i + 1}. ${q.title}</div>
          <div class="pm-question-help">${q.help}</div>
          <div class="pm-choices">
            ${options.map(opt => {
              const active = answers[q.id] === opt.value || (opt.value !== 'na' && answers[q.id] === Number(opt.value));
              return `<button type="button" class="pm-choice ${opt.className || ''} ${active ? 'pm-active' : ''}" data-q="${q.id}" data-value="${opt.value}">${opt.label}</button>`;
            }).join('')}
          </div>
        </div>
      `).join('');

      el.questionStack.querySelectorAll('.pm-choice').forEach(btn => {
        btn.addEventListener('click', () => {
          const qid = btn.getAttribute('data-q');
          const raw = btn.getAttribute('data-value');
          answers[qid] = raw === 'na' ? 'na' : parseInt(raw, 10);
          renderStep();
          refresh();
        });
      });

      const answeredThisStep = dim.questions.filter(q => answers[q.id] !== undefined).length;
      el.stepHint.textContent = answeredThisStep === dim.questions.length
        ? 'Cette dimension est complète. Tu peux continuer ou ouvrir le rapport.'
        : `Cette dimension est renseignée à ${answeredThisStep}/${dim.questions.length}.`;
    }

    function renderNav(){
      el.navList.innerHTML = dimensions.map((dim, idx) => {
        const answered = dim.questions.filter(q => answers[q.id] !== undefined).length;
        const done = answered === dim.questions.length;
        const active = idx === currentStep && !reportMode;
        return `
          <div class="pm-nav-item ${done ? 'pm-done' : ''} ${active ? 'pm-active' : ''}" data-step="${idx}">
            <div class="pm-nav-num">${idx + 1}</div>
            <div class="pm-nav-title">${dim.title}</div>
            <div class="pm-nav-desc">${answered}/${dim.questions.length} réponses</div>
          </div>
        `;
      }).join('');
      el.navList.querySelectorAll('.pm-nav-item').forEach(item => {
        item.addEventListener('click', () => {
          currentStep = parseInt(item.getAttribute('data-step'), 10);
          reportMode = false;
          renderStep();
          refresh();
        });
      });
    }

    function buildState(){
      const scores = getDimensionScores();
      const maturity = calcMaturity(scores);
      const urgency = calcUrgency();
      const completion = countCompletion().percent;
      const stability = calcStability(scores);
      const reco = recommendation(maturity, urgency, completion);
      const prios = priorities(scores);
      const comm = commercial(reco);
      const strengths = scores.filter(d => d.score !== null).sort((a,b)=>b.score-a.score).slice(0,2).map(d=>d.title);
      const weaknesses = scores.filter(d => d.score !== null).sort((a,b)=>a.score-b.score).slice(0,3).map(d=>d.title);
      return { scores, maturity, urgency, completion, stability, reco, prios, comm, strengths, weaknesses };
    }

    function payloadForSave(){
      const state = buildState();
      return {
        id: currentSavedId,
        meta: {
          client: el.metaClient.value,
          date: el.metaDate.value,
          reference: el.metaReference.value,
          owner: el.metaOwner.value,
          theme: el.metaTheme.value,
          reportMode: el.reportModeSelect.value
        },
        recommendation: state.reco,
        scores: {
          maturity: state.maturity,
          urgency: state.urgency,
          completion: state.completion,
          stability: state.stability
        },
        summary: summary(state.maturity, state.urgency, state.completion, state.scores, state.stability),
        priorities: state.prios,
        commercial: state.comm,
        strengths: state.strengths,
        weaknesses: state.weaknesses,
        dimensions: state.scores,
        answers: answers
      };
    }

    async function api(path, method='GET', data=null){
      const opts = {
        method,
        headers: { 'X-WP-Nonce': cfg.nonce }
      };
      if (data) {
        opts.headers['Content-Type'] = 'application/json';
        opts.body = JSON.stringify(data);
      }
      const res = await fetch(cfg.restRoot + path, opts);
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || 'Erreur API');
      return json;
    }

    async function saveDiagnostic(el){
      try{
        el.saveStatus.textContent = 'Enregistrement en cours...';
        const result = await api('/save', 'POST', payloadForSave());
        currentSavedId = result.id;
        el.saveStatus.textContent = result.message;
        await loadSavedList();
      }catch(err){
        el.saveStatus.textContent = err.message;
      }
    }

    async function loadSavedList(){
      try{
        const items = await api('/list');
        if (!items.length) {
          el.savedList.textContent = 'Aucun dossier enregistré.';
          return;
        }
        el.savedList.innerHTML = items.map(item => `
          <div class="pm-saved-item">
            <strong>${escapeHtml(item.title)}</strong>
            <div>${escapeHtml(item.date || '')}</div>
            <div class="pm-saved-actions">
              <button type="button" class="pm-btn-small" data-load-id="${item.id}">Ouvrir</button>
              <button type="button" class="pm-btn-small" data-delete-id="${item.id}">Supprimer</button>
              ${item.link ? `<a class="pm-btn-small" href="${item.link}" target="_blank" rel="noopener">Éditer WP</a>` : ''}
            </div>
          </div>
        `).join('');
        el.savedList.querySelectorAll('[data-load-id]').forEach(btn => {
          btn.addEventListener('click', async () => {
            await loadDiagnostic(parseInt(btn.getAttribute('data-load-id'), 10));
          });
        });
        el.savedList.querySelectorAll('[data-delete-id]').forEach(btn => {
          btn.addEventListener('click', async () => {
            if (!confirm('Supprimer ce diagnostic ?')) return;
            await api('/delete/' + btn.getAttribute('data-delete-id'), 'DELETE');
            if (currentSavedId === parseInt(btn.getAttribute('data-delete-id'), 10)) currentSavedId = null;
            await loadSavedList();
          });
        });
      }catch(err){
        el.savedList.textContent = err.message;
      }
    }

    async function loadDiagnostic(id){
      try{
        const data = await api('/get/' + id);
        currentSavedId = id;
        Object.keys(answers).forEach(k => delete answers[k]);
        Object.entries(data.answers || {}).forEach(([k,v]) => { answers[k] = v; });
        if (data.meta) {
          el.metaClient.value = data.meta.client || '';
          el.metaDate.value = data.meta.date || '';
          el.metaReference.value = data.meta.reference || '';
          el.metaOwner.value = data.meta.owner || '';
          el.metaTheme.value = data.meta.theme || cfg.themeDefault || 'cabinet';
          el.reportModeSelect.value = data.meta.reportMode || 'client';
        }
        reportMode = true;
        renderStep();
        refresh();
        el.saveStatus.textContent = 'Diagnostic chargé.';
      }catch(err){
        el.saveStatus.textContent = err.message;
      }
    }

    function refresh(){
      const state = buildState();
      const mode = el.reportModeSelect.value || 'client';

      el.liveMaturity.textContent = `${state.maturity}/100`;
      el.liveUrgency.textContent = `${state.urgency}/100`;
      el.liveCompletion.textContent = `${state.completion}%`;
      el.liveMaturityBar.style.width = `${state.maturity}%`;
      el.liveUrgencyBar.style.width = `${state.urgency}%`;
      el.liveCompletionBar.style.width = `${state.completion}%`;
      el.progressLabel.textContent = `${state.completion}%`;
      el.progressBar.style.width = `${state.completion}%`;

      el.reportReco.textContent = state.reco.name;
      el.reportSummary.innerHTML = summary(state.maturity, state.urgency, state.completion, state.scores, state.stability);
      el.reportTags.innerHTML = state.reco.tags.map(tag => `<span class="pm-pill">${tag}</span>`).join('');
      el.prioritiesList.innerHTML = state.prios.map(item => `<div class="pm-item"><strong>${item.title}</strong>${item.text}</div>`).join('');
      el.commercialList.innerHTML = state.comm.map(item => `<div class="pm-item"><strong>${item.title}</strong>${item.text}</div>`).join('');
      el.strengthsList.innerHTML = state.strengths.map(item => `<span class="pm-pill">${item}</span>`).join('') || '—';
      el.weaknessesList.innerHTML = state.weaknesses.map(item => `<span class="pm-pill">${item}</span>`).join('') || '—';
      el.internalNotes.innerHTML = internalNotes(state).map(item => `<div class="pm-item"><strong>${item.title}</strong>${item.text}</div>`).join('');
      el.internalOnly.forEach(block => block.classList.toggle('pm-hidden-block', mode !== 'internal'));

      renderNav();
      el.wizardView.classList.toggle('pm-hidden', reportMode);
      el.reportView.classList.toggle('pm-hidden', !reportMode);
    }

    function goNext(){
      if (currentStep < dimensions.length - 1) currentStep += 1;
      else reportMode = true;
      renderStep();
      refresh();
    }

    function goPrev(){
      if (currentStep > 0) currentStep -= 1;
      renderStep();
      refresh();
    }

    function resetAll(){
      Object.keys(answers).forEach(k => delete answers[k]);
      currentStep = 0;
      reportMode = false;
      currentSavedId = null;
      el.metaDate.value = new Date().toISOString().slice(0, 10);
      renderStep();
      refresh();
      el.saveStatus.textContent = 'Diagnostic réinitialisé.';
    }

    function fillDemo(){
      const demo = {
        vision1:2, vision2:2, vision3:1,
        finance1:2, finance2:1, finance3:1,
        ops1:2, ops2:3, ops3:2,
        admin1:1, admin2:2, admin3:1,
        digital1:2, digital2:2, digital3:2,
        marketing1:2, marketing2:2, marketing3:1,
        data1:1, data2:2, data3:1,
        risks1:2, risks2:2, risks3:1
      };
      Object.keys(answers).forEach(k => delete answers[k]);
      Object.entries(demo).forEach(([k,v]) => { answers[k] = v; });
      currentStep = 0;
      reportMode = false;
      renderStep();
      refresh();
      el.saveStatus.textContent = 'Cas démo chargé.';
    }

    function downloadJson(el){
      const payload = payloadForSave();
      const blob = new Blob([JSON.stringify(payload, null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(payload.meta.reference || 'POLY-DIAG')}_polymate_diagnostic.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    }

    function escapeHtml(str){
      return (str || '').replace(/[&<>"']/g, function(m){
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[m];
      });
    }

    renderStep();
    refresh();
    loadSavedList();
  }
})();
