<?php
/**
 * Plugin Name: Polymate Diagnostic V2
 * Description: Diagnostic interactif Polymate pour WordPress avec sauvegarde, mode client/interne, export JSON et vue d'impression.
 * Version: 0.2.0
 * Author: OpenAI for Olivier Guex
 * Text Domain: polymate-diagnostic
 */

if (!defined('ABSPATH')) {
    exit;
}

define('POLYMATE_DIAG_V2_VERSION', '0.2.0');
define('POLYMATE_DIAG_V2_FILE', __FILE__);
define('POLYMATE_DIAG_V2_PATH', plugin_dir_path(__FILE__));
define('POLYMATE_DIAG_V2_URL', plugin_dir_url(__FILE__));

require_once POLYMATE_DIAG_V2_PATH . 'includes/class-polymate-diagnostic-v2.php';

function polymate_diagnostic_v2() {
    return Polymate_Diagnostic_V2::instance();
}
polymate_diagnostic_v2();
