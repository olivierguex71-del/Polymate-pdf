<?php
if (!defined('ABSPATH')) {
    exit;
}

class Polymate_Diagnostic_V2 {
    private static $instance = null;
    private $option_name = 'polymate_diagnostic_v2_settings';
    private $post_type = 'polymate_diag';

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'register_post_type']);
        add_action('init', [$this, 'register_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_filter('manage_' . $this->post_type . '_posts_columns', [$this, 'filter_columns']);
        add_action('manage_' . $this->post_type . '_posts_custom_column', [$this, 'render_column'], 10, 2);
    }

    public function register_post_type() {
        register_post_type($this->post_type, [
            'labels' => [
                'name' => 'Diagnostics Polymate',
                'singular_name' => 'Diagnostic Polymate',
                'menu_name' => 'Diagnostics Polymate',
                'add_new_item' => 'Ajouter un diagnostic',
                'edit_item' => 'Modifier le diagnostic',
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => ['title'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);
    }

    public function register_shortcode() {
        add_shortcode('polymate_diagnostic', [$this, 'render_shortcode']);
    }

    public function register_assets() {
        wp_register_style(
            'polymate-diagnostic-v2',
            POLYMATE_DIAG_V2_URL . 'assets/css/app.css',
            [],
            POLYMATE_DIAG_V2_VERSION
        );

        wp_register_script(
            'polymate-diagnostic-v2',
            POLYMATE_DIAG_V2_URL . 'assets/js/app.js',
            [],
            POLYMATE_DIAG_V2_VERSION,
            true
        );
    }

    public function render_shortcode($atts = []) {
        wp_enqueue_style('polymate-diagnostic-v2');
        wp_enqueue_script('polymate-diagnostic-v2');

        $settings = $this->get_settings();
        $config = [
            'restRoot' => esc_url_raw(rest_url('polymate-diagnostic/v2')),
            'nonce' => wp_create_nonce('wp_rest'),
            'themeDefault' => $settings['default_theme'],
            'defaultOwner' => $settings['default_owner'],
            'brandLine' => $settings['brand_line'],
            'pdfServiceUrl' => $settings['pdf_service_url'],
            'dimensions' => $this->get_dimensions(),
            'labels' => [
                'brand' => 'Polymate',
                'subtitle' => 'Diagnostic de prise en charge',
            ],
        ];

        wp_localize_script('polymate-diagnostic-v2', 'PolymateDiagnosticV2Config', $config);

        ob_start();
        ?>
        <div class="polymate-diagnostic-app" data-polymate-app>
            <section class="pm-hero pm-card">
                <div class="pm-hero-main">
                    <div class="pm-eyebrow"><?php echo esc_html($settings['brand_line']); ?></div>
                    <h1>Diagnostic Polymate V2</h1>
                    <p class="pm-lead">
                        Version WordPress enrichie : diagnostic interactif, sauvegarde des dossiers, mode client / interne,
                        export JSON, vue d’impression et passerelle prête pour un futur moteur PDF premium.
                    </p>
                    <div class="pm-toolbar">
                        <button type="button" class="pm-btn pm-btn-primary" data-action="demo">Charger un cas démo</button>
                        <button type="button" class="pm-btn pm-btn-secondary" data-action="reset">Réinitialiser</button>
                        <button type="button" class="pm-btn pm-btn-secondary" data-action="report">Voir le rapport</button>
                    </div>
                </div>
                <div class="pm-hero-side">
                    <div class="pm-mini-card">
                        <div class="pm-k">Mode</div>
                        <div class="pm-v">Client</div>
                        <div class="pm-d">Lecture commerciale épurée, adaptée à la restitution en rendez-vous.</div>
                    </div>
                    <div class="pm-mini-card">
                        <div class="pm-k">Mode</div>
                        <div class="pm-v">Interne</div>
                        <div class="pm-d">Plus de matière stratégique pour l’usage interne Polymate.</div>
                    </div>
                    <div class="pm-mini-card">
                        <div class="pm-k">Sauvegarde</div>
                        <div class="pm-v">WP</div>
                        <div class="pm-d">Les diagnostics peuvent être enregistrés comme dossiers WordPress.</div>
                    </div>
                    <div class="pm-mini-card">
                        <div class="pm-k">Suite</div>
                        <div class="pm-v">PDF+</div>
                        <div class="pm-d">Prêt à dialoguer plus tard avec un service PDF externe ou interne.</div>
                    </div>
                </div>
            </section>

            <section class="pm-layout">
                <aside class="pm-sidebar">
                    <div class="pm-score-grid">
                        <div class="pm-stat-card">
                            <div class="pm-stat-title">Maturité</div>
                            <div class="pm-stat-value" data-live-maturity>0/100</div>
                            <div class="pm-meter pm-meter-maturity"><span data-live-maturity-bar></span></div>
                            <div class="pm-stat-text">Capacité à fonctionner, piloter et structurer.</div>
                        </div>
                        <div class="pm-stat-card">
                            <div class="pm-stat-title">Urgence</div>
                            <div class="pm-stat-value" data-live-urgency>0/100</div>
                            <div class="pm-meter pm-meter-urgency"><span data-live-urgency-bar></span></div>
                            <div class="pm-stat-text">Tension appelant une reprise en main.</div>
                        </div>
                    </div>
                    <div class="pm-stat-card">
                        <div class="pm-stat-title">Complétude</div>
                        <div class="pm-stat-value" data-live-completion>0%</div>
                        <div class="pm-meter pm-meter-completion"><span data-live-completion-bar></span></div>
                        <div class="pm-stat-text">Part des réponses effectivement renseignées.</div>
                    </div>
                    <div class="pm-stat-card">
                        <div class="pm-stat-title">Navigation</div>
                        <div class="pm-nav-list" data-nav-list></div>
                    </div>
                    <div class="pm-stat-card">
                        <div class="pm-stat-title">Dossiers enregistrés</div>
                        <div class="pm-saved-list" data-saved-list>Chargement…</div>
                    </div>
                </aside>

                <main class="pm-main pm-card">
                    <section class="pm-wizard-view" data-view="wizard">
                        <div class="pm-wizard-head">
                            <div class="pm-wizard-kicker" data-step-kicker>Étape 1</div>
                            <div class="pm-wizard-title" data-step-title>Vision & gouvernance</div>
                            <p class="pm-wizard-desc" data-step-desc></p>
                            <div class="pm-progress-wrap">
                                <div class="pm-progress-meta">
                                    <span>Progression globale</span>
                                    <span data-progress-label>0%</span>
                                </div>
                                <div class="pm-progress"><span data-progress-bar></span></div>
                            </div>
                        </div>
                        <div class="pm-wizard-body">
                            <div class="pm-question-stack" data-question-stack></div>
                        </div>
                        <div class="pm-wizard-foot">
                            <div class="pm-toolbar">
                                <button type="button" class="pm-btn pm-btn-secondary" data-action="prev">Précédent</button>
                                <button type="button" class="pm-btn pm-btn-secondary" data-action="report">Rapport</button>
                            </div>
                            <div class="pm-hint" data-step-hint></div>
                            <div class="pm-toolbar">
                                <button type="button" class="pm-btn pm-btn-secondary" data-action="next">Suivant</button>
                            </div>
                        </div>
                    </section>

                    <section class="pm-report-view pm-hidden" data-view="report">
                        <div class="pm-report-grid">
                            <div class="pm-report-block">
                                <div class="pm-report-title">Lecture actuelle</div>
                                <div class="pm-report-name" data-report-reco>Structure</div>
                                <div class="pm-report-summary" data-report-summary></div>
                                <div class="pm-pill-wrap" data-report-tags></div>
                            </div>

                            <div class="pm-report-block">
                                <div class="pm-report-title">Métadonnées</div>
                                <div class="pm-form-grid">
                                    <label class="pm-field">
                                        <span>Client</span>
                                        <input type="text" data-meta-client value="Nom du client">
                                    </label>
                                    <label class="pm-field">
                                        <span>Date</span>
                                        <input type="date" data-meta-date>
                                    </label>
                                    <label class="pm-field">
                                        <span>Référence</span>
                                        <input type="text" data-meta-reference value="POLY-DIAG-001">
                                    </label>
                                    <label class="pm-field">
                                        <span>Chargé de mission</span>
                                        <input type="text" data-meta-owner value="<?php echo esc_attr($settings['default_owner']); ?>">
                                    </label>
                                    <label class="pm-field">
                                        <span>Thème visuel</span>
                                        <select data-meta-theme>
                                            <option value="cabinet">Cabinet</option>
                                            <option value="graphite">Graphite</option>
                                            <option value="executive">Executive</option>
                                            <option value="impact">Impact</option>
                                        </select>
                                    </label>
                                    <label class="pm-field">
                                        <span>Version du rapport</span>
                                        <select data-report-mode>
                                            <option value="client">Client</option>
                                            <option value="internal">Interne</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="pm-toolbar pm-toolbar-tight">
                                    <button type="button" class="pm-btn pm-btn-secondary" data-action="back">Retour au questionnaire</button>
                                    <button type="button" class="pm-btn pm-btn-secondary" data-action="print">Imprimer / PDF</button>
                                    <button type="button" class="pm-btn pm-btn-secondary" data-action="download-json">Télécharger JSON</button>
                                    <button type="button" class="pm-btn pm-btn-primary" data-action="save">Enregistrer</button>
                                </div>
                                <div class="pm-note" data-save-status>
                                    Le plugin enregistre les diagnostics et prépare l’intégration d’une future brique PDF premium.
                                </div>
                            </div>

                            <div class="pm-report-block">
                                <div class="pm-report-title">Priorités d’action</div>
                                <div class="pm-list" data-priorities-list></div>
                            </div>

                            <div class="pm-report-block">
                                <div class="pm-report-title">Lecture commerciale</div>
                                <div class="pm-list" data-commercial-list></div>
                            </div>

                            <div class="pm-report-block pm-report-block-internal" data-internal-only>
                                <div class="pm-report-title">Notes internes</div>
                                <div class="pm-list" data-internal-notes></div>
                            </div>

                            <div class="pm-report-block">
                                <div class="pm-report-title">Points d’appui</div>
                                <div class="pm-pill-wrap" data-strengths-list></div>
                            </div>

                            <div class="pm-report-block">
                                <div class="pm-report-title">Zones de fragilité</div>
                                <div class="pm-pill-wrap" data-weaknesses-list></div>
                            </div>
                        </div>
                    </section>
                </main>
            </section>
        </div>
        <?php
        return ob_get_clean();
    }

    public function register_admin_menu() {
        add_menu_page(
            'Polymate Diagnostic',
            'Polymate Diagnostic',
            'manage_options',
            'polymate-diagnostic-v2',
            [$this, 'render_settings_page'],
            'dashicons-chart-area',
            58
        );

        add_submenu_page(
            'polymate-diagnostic-v2',
            'Réglages',
            'Réglages',
            'manage_options',
            'polymate-diagnostic-v2',
            [$this, 'render_settings_page']
        );

        add_submenu_page(
            'polymate-diagnostic-v2',
            'Diagnostics enregistrés',
            'Diagnostics enregistrés',
            'manage_options',
            'edit.php?post_type=' . $this->post_type
        );
    }

    public function register_settings() {
        register_setting('polymate_diagnostic_v2', $this->option_name, [$this, 'sanitize_settings']);

        add_settings_section('polymate_diagnostic_v2_main', 'Réglages généraux', '__return_false', 'polymate-diagnostic-v2');

        $fields = [
            ['key' => 'brand_line', 'label' => 'Ligne de marque'],
            ['key' => 'default_owner', 'label' => 'Chargé de mission par défaut'],
            ['key' => 'pdf_service_url', 'label' => 'URL service PDF externe (optionnel)'],
        ];

        foreach ($fields as $field) {
            add_settings_field(
                $field['key'],
                $field['label'],
                [$this, 'render_text_field'],
                'polymate-diagnostic-v2',
                'polymate_diagnostic_v2_main',
                ['key' => $field['key']]
            );
        }

        add_settings_field(
            'default_theme',
            'Thème par défaut',
            [$this, 'render_theme_field'],
            'polymate-diagnostic-v2',
            'polymate_diagnostic_v2_main'
        );
    }

    public function sanitize_settings($input) {
        return [
            'brand_line'    => sanitize_text_field($input['brand_line'] ?? 'Polymate · Diagnostic'),
            'default_owner' => sanitize_text_field($input['default_owner'] ?? ''),
            'default_theme' => sanitize_key($input['default_theme'] ?? 'cabinet'),
            'pdf_service_url' => esc_url_raw($input['pdf_service_url'] ?? ''),
        ];
    }

    public function render_text_field($args) {
        $settings = $this->get_settings();
        $key = $args['key'];
        printf(
            '<input type="text" class="regular-text" name="%1$s[%2$s]" value="%3$s">',
            esc_attr($this->option_name),
            esc_attr($key),
            esc_attr($settings[$key] ?? '')
        );
    }

    public function render_theme_field() {
        $settings = $this->get_settings();
        $current = $settings['default_theme'];
        $themes = ['cabinet' => 'Cabinet', 'graphite' => 'Graphite', 'executive' => 'Executive', 'impact' => 'Impact'];
        echo '<select name="' . esc_attr($this->option_name) . '[default_theme]">';
        foreach ($themes as $key => $label) {
            printf('<option value="%1$s" %2$s>%3$s</option>', esc_attr($key), selected($current, $key, false), esc_html($label));
        }
        echo '</select>';
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Polymate Diagnostic V2</h1>
            <p>Place le shortcode <code>[polymate_diagnostic]</code> sur une page WordPress pour afficher l’outil.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields('polymate_diagnostic_v2');
                do_settings_sections('polymate-diagnostic-v2');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function register_rest_routes() {
        register_rest_route('polymate-diagnostic/v2', '/save', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_save_diagnostic'],
            'permission_callback' => function () {
                return current_user_can('edit_posts');
            },
        ]);

        register_rest_route('polymate-diagnostic/v2', '/list', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_list_diagnostics'],
            'permission_callback' => function () {
                return current_user_can('edit_posts');
            },
        ]);

        register_rest_route('polymate-diagnostic/v2', '/get/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_diagnostic'],
            'permission_callback' => function () {
                return current_user_can('edit_posts');
            },
        ]);

        register_rest_route('polymate-diagnostic/v2', '/delete/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$this, 'rest_delete_diagnostic'],
            'permission_callback' => function () {
                return current_user_can('delete_posts');
            },
        ]);
    }

    public function rest_save_diagnostic($request) {
        $data = $request->get_json_params();
        $meta = $data['meta'] ?? [];
        $title = !empty($meta['client']) ? sanitize_text_field($meta['client']) : 'Diagnostic sans nom';
        $reference = sanitize_text_field($meta['reference'] ?? 'POLY-DIAG');

        $post_id = !empty($data['id']) ? absint($data['id']) : 0;

        $post_args = [
            'post_type' => $this->post_type,
            'post_title' => $title . ' — ' . $reference,
            'post_status' => 'publish',
        ];

        if ($post_id) {
            $post_args['ID'] = $post_id;
            $post_id = wp_update_post($post_args, true);
        } else {
            $post_id = wp_insert_post($post_args, true);
        }

        if (is_wp_error($post_id)) {
            return new WP_REST_Response(['message' => $post_id->get_error_message()], 500);
        }

        update_post_meta($post_id, '_polymate_payload', wp_json_encode($data));
        update_post_meta($post_id, '_polymate_reference', $reference);
        update_post_meta($post_id, '_polymate_client', sanitize_text_field($meta['client'] ?? ''));
        update_post_meta($post_id, '_polymate_date', sanitize_text_field($meta['date'] ?? ''));
        update_post_meta($post_id, '_polymate_mode', sanitize_text_field($meta['reportMode'] ?? 'client'));

        return new WP_REST_Response([
            'id' => $post_id,
            'message' => 'Diagnostic enregistré.',
        ], 200);
    }

    public function rest_list_diagnostics() {
        $posts = get_posts([
            'post_type' => $this->post_type,
            'post_status' => 'publish',
            'numberposts' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        $items = array_map(function ($post) {
            return [
                'id' => $post->ID,
                'title' => $post->post_title,
                'client' => get_post_meta($post->ID, '_polymate_client', true),
                'reference' => get_post_meta($post->ID, '_polymate_reference', true),
                'date' => get_post_meta($post->ID, '_polymate_date', true),
                'link' => get_edit_post_link($post->ID, ''),
            ];
        }, $posts);

        return new WP_REST_Response($items, 200);
    }

    public function rest_get_diagnostic($request) {
        $id = absint($request['id']);
        $raw = get_post_meta($id, '_polymate_payload', true);
        if (!$raw) {
            return new WP_REST_Response(['message' => 'Diagnostic introuvable.'], 404);
        }
        return new WP_REST_Response(json_decode($raw, true), 200);
    }

    public function rest_delete_diagnostic($request) {
        $id = absint($request['id']);
        $deleted = wp_delete_post($id, true);
        if (!$deleted) {
            return new WP_REST_Response(['message' => 'Suppression impossible.'], 500);
        }
        return new WP_REST_Response(['message' => 'Diagnostic supprimé.'], 200);
    }

    public function filter_columns($columns) {
        $columns['polymate_client'] = 'Client';
        $columns['polymate_reference'] = 'Référence';
        $columns['polymate_date'] = 'Date diagnostic';
        return $columns;
    }

    public function render_column($column, $post_id) {
        if ($column === 'polymate_client') {
            echo esc_html(get_post_meta($post_id, '_polymate_client', true));
        }
        if ($column === 'polymate_reference') {
            echo esc_html(get_post_meta($post_id, '_polymate_reference', true));
        }
        if ($column === 'polymate_date') {
            echo esc_html(get_post_meta($post_id, '_polymate_date', true));
        }
    }

    private function get_settings() {
        $defaults = [
            'brand_line' => 'Polymate · Diagnostic',
            'default_owner' => '',
            'default_theme' => 'cabinet',
            'pdf_service_url' => '',
        ];
        return wp_parse_args(get_option($this->option_name, []), $defaults);
    }

    private function get_dimensions() {
        return [
            ['id'=>'vision','title'=>'Vision & gouvernance','desc'=>'Le cap, la clarté des rôles et la capacité du dirigeant à piloter sans subir.','weight'=>1.5,'questions'=>[
                ['id'=>'vision1','title'=>'La vision à 1–3 ans est claire et formulée.','help'=>'0 = aucune direction claire · 3 = cap explicite et partagé'],
                ['id'=>'vision2','title'=>'Les rôles et responsabilités sont bien définis.','help'=>'0 = confusion fréquente · 3 = responsabilités nettes'],
                ['id'=>'vision3','title'=>'L’entreprise n’est pas entièrement dépendante du dirigeant.','help'=>'0 = tout repose sur lui · 3 = fonctionnement partiellement autonomisé','urgency'=>[10,7,3,0]],
            ]],
            ['id'=>'finance','title'=>'Finance & pilotage','desc'=>'La lecture de la trésorerie, le budget et la capacité à décider avec des chiffres.','weight'=>2,'questions'=>[
                ['id'=>'finance1','title'=>'La comptabilité est à jour et exploitable.','help'=>'0 = retard important · 3 = à jour et lisible','urgency'=>[10,6,2,0]],
                ['id'=>'finance2','title'=>'La trésorerie est visible et suivie régulièrement.','help'=>'0 = angle mort · 3 = suivi régulier','urgency'=>[12,8,3,0]],
                ['id'=>'finance3','title'=>'Un budget ou un reporting sert réellement au pilotage.','help'=>'0 = aucun pilotage · 3 = budget / reporting actif','urgency'=>[8,5,2,0]],
            ]],
            ['id'=>'ops','title'=>'Opérations & organisation','desc'=>'Les processus, la fluidité des tâches et la fiabilité de l’exécution.','weight'=>2,'questions'=>[
                ['id'=>'ops1','title'=>'Les processus clés sont documentés ou stabilisés.','help'=>'0 = tout est implicite · 3 = fonctionnement reproductible'],
                ['id'=>'ops2','title'=>'Les flux commande → facture → encaissement sont efficaces.','help'=>'0 = pertes / oublis · 3 = chaîne maîtrisée','urgency'=>[7,5,2,0]],
                ['id'=>'ops3','title'=>'L’organisation ne dépend pas de quelques personnes-clés seulement.','help'=>'0 = forte fragilité · 3 = redondance minimale','urgency'=>[9,6,3,0]],
            ]],
            ['id'=>'admin','title'=>'Administratif & RH','desc'=>'Le socle discret mais vital : contrats, salaires, stabilité administrative, charge dirigeant.','weight'=>1,'questions'=>[
                ['id'=>'admin1','title'=>'La gestion administrative est stable et fluide.','help'=>'0 = surcharge ou chaos · 3 = base solide'],
                ['id'=>'admin2','title'=>'Les éléments RH essentiels sont suivis correctement.','help'=>'0 = fragilité importante · 3 = cadre propre'],
                ['id'=>'admin3','title'=>'Le dirigeant n’est pas aspiré par l’administratif.','help'=>'0 = il compense tout · 3 = charge bien répartie','urgency'=>[6,4,2,0]],
            ]],
            ['id'=>'digital','title'=>'Digital & systèmes','desc'=>'Outils, sécurité, centralisation et potentiel d’automatisation.','weight'=>1.5,'questions'=>[
                ['id'=>'digital1','title'=>'Les outils utilisés sont cohérents et suffisamment intégrés.','help'=>'0 = empilement bricolé · 3 = stack lisible'],
                ['id'=>'digital2','title'=>'Les données sont sécurisées et sauvegardées.','help'=>'0 = risque élevé · 3 = sécurité de base fiable','urgency'=>[8,5,2,0]],
                ['id'=>'digital3','title'=>'Le digital soutient l’efficacité au lieu de la freiner.','help'=>'0 = perte de temps · 3 = levier opérationnel'],
            ]],
            ['id'=>'marketing','title'=>'Marketing & communication','desc'=>'Clarté du positionnement, acquisition et visibilité de l’offre.','weight'=>1,'questions'=>[
                ['id'=>'marketing1','title'=>'Le positionnement de l’entreprise est clair.','help'=>'0 = message flou · 3 = promesse lisible'],
                ['id'=>'marketing2','title'=>'L’acquisition de clients ne dépend pas d’un seul canal fragile.','help'=>'0 = dépendance unique · 3 = sources diversifiées','urgency'=>[6,4,2,0]],
                ['id'=>'marketing3','title'=>'Les prospects sont suivis de façon structurée.','help'=>'0 = au hasard · 3 = suivi simple mais régulier'],
            ]],
            ['id'=>'data','title'=>'Données & pilotage global','desc'=>'Tableaux de bord, indicateurs et lecture transversale de l’entreprise.','weight'=>1.5,'questions'=>[
                ['id'=>'data1','title'=>'Des indicateurs simples existent pour piloter l’activité.','help'=>'0 = feeling pur · 3 = quelques KPI bien suivis'],
                ['id'=>'data2','title'=>'Les décisions sont prises avec des données fiables.','help'=>'0 = intuition seule · 3 = données exploitables'],
                ['id'=>'data3','title'=>'Une vision synthétique de l’entreprise est disponible.','help'=>'0 = angles morts · 3 = cockpit minimal','urgency'=>[7,4,2,0]],
            ]],
            ['id'=>'risks','title'=>'Risques & signaux faibles','desc'=>'Dépendances, tensions cachées, transmission, départs et vulnérabilités latentes.','weight'=>2,'questions'=>[
                ['id'=>'risks1','title'=>'Il n’existe pas de dépendance critique à un client, personne ou prestataire.','help'=>'0 = forte dépendance · 3 = risque contenu','urgency'=>[10,6,3,0]],
                ['id'=>'risks2','title'=>'Il n’y a pas de projet sensible mal préparé.','help'=>'0 = sujet majeur non traité · 3 = rien de critique','urgency'=>[12,7,3,0]],
                ['id'=>'risks3','title'=>'Le dirigeant garde une capacité de recul et de maîtrise.','help'=>'0 = saturation / usure · 3 = maîtrise relative','urgency'=>[10,7,3,0]],
            ]],
        ];
    }
}
